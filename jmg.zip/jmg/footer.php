<div class="container footer">
	<div class="row">
		<div class="col col-span-1 address">
			<img src="<?php echo get_static_uri('header_footer/jmg_logo_wht.png');?>"/><br/>
			Telephone 61 8 9 316 2508<br/>
			E-mail. admin@jmgbuildingsurveyors.com.au 
		</div>
		<div class="col col-span-2">
			<div>
				<img src="<?php echo get_static_uri('header_footer/facebook.png');?>"/>
				<img src="<?php echo get_static_uri('header_footer/twitter.png');?>"/>
			</div>
			<ul>
				<li><a href="">Home</a></li>
				<li><a href="">About</a></li>
				<li><a href="">Projects</a></li>
				<li><a href="">Services</a></li>
				<li><a href="">Blog</a></li>
				<li><a href="">Contact</a></li>
			</ul> 
			&copy; JMG Building Surveyors 2015
		</div>
		<div class="col col-span-1">
			<img src="<?php echo get_static_uri('header_footer/council_logo.png');?>"/><br/>
		</div>

	</div>
</div>
<?php wp_footer();?> 
</body>
</html>