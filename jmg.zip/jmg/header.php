<?php get_template_part('head'); ?>
<body>
	<?php get_template_part('menu'); ?>
