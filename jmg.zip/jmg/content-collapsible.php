<?php
return'
<div>
	<span class="toggle" onclick="return toggle(this.parentNode)">-</span>
	<span class="toggleTitle">'.$a["title"].'</span>
</div>
<p class="toggleContent small">
'.$a["content"].'
</p>
';
?>
